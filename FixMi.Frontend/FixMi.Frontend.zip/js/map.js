﻿var map;
var marker;

function initializeMap(mapDiv, lat, long) {
    var latlng = new google.maps.LatLng(lat, long);
    var myOptions = {
        zoom: 8,
        center: latlng,
        mapTypeId: google.maps.MapTypeId.ROADMAP,
        scaleControl: false, mapTypeControl: false, disableDefaultUI: true, disableDoubleClickZoom: true,
        scrollwheel: false
        //click: function () { setMarker(); }
    };

    map = new google.maps.Map(document.getElementById(mapDiv), myOptions);
}

function geo(address) {
    if (map) {
        var addr = address + ', Milano';
        var geoCoder = new google.maps.Geocoder();
        geoCoder.geocode({ address: addr }, function (response, status) { geolocation_response(response, status); });
    }
}

function geolocation_response(r, status) {
    if (status == google.maps.GeocoderStatus.OK) {
        var data = r[0];

        map.setCenter(data.geometry.location);
        switch (data.types[0]) {
            case 'street_address':
                map.setZoom(16);
                break;
            case 'postal_code':
                map.setZoom(14);
                break;
            case 'sublocality':
                map.setZoom(13);
                break;
            case 'route':
                map.setZoom(15);
                break;
        }

        setMarker(data.geometry.location);
    }
}

function setMarker(location) {
    if (marker)
        marker.setMap(null);

    marker = new google.maps.Marker({
        position: location,
        map: map,
        draggable: true
    });
}